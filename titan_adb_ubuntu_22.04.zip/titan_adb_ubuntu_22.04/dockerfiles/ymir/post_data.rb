# frozen_string_literal: true

require 'readline'
require 'net/http'

STDOUT.sync = true

class ResultConnection
  def initialize(message_url)
    @header = { 'Content-Type': 'application/json' }
    @uri = URI.parse(message_url)

    @http = Net::HTTP.start(@uri.host, @uri.port)
    @http.read_timeout = 100
  end

  def post_entry(content)
    return '<empty read>' if content.empty?

    request = Net::HTTP::Put.new(@uri.request_uri, @header)
    request.body = content

    "#{@http.request(request).code}: #{content}"
  end
end

def read_entry
  STDIN.readline
rescue EOFError
  exit(0)
end

message_url = ENV['MESSAGE_URL'] || 'http://localhost:8972/api/message'

# wait for test updates
begin
  result_connection = ResultConnection.new(message_url)
rescue StandardError => e
  puts "Error connecting to `#{message_url}`: #{e.message}"
  puts e.backtrace.take(10)
  exit(1)
end

loop do
  content = read_entry

  puts result_connection.post_entry(content)
end
