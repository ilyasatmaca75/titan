# just adding this
STDOUT.sync = true
