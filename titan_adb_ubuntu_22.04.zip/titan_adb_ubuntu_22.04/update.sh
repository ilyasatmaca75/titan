#!/bin/sh

# -------------------------------------------------
# Overview
# -------------------------------------------------

# > This script performs a setup and/or update of the pdv-testing service on a PI, which runs Titan and enables pdv testing.

# -------------------------------------------------
# Instructions
# -------------------------------------------------

# Step 1 - Get Titan on PI
# > See the wiki for instructions on how to get Titan on PI
# > https://github.siriusxm.com/svt/titan/wiki/Get-Titan-on-PI

# Step 2. Execute This Script on PI
# > Run: '. ~/<path-to-latest-titan-release-on-pi>/update.sh'

# -------------------------------------------------

# Sets the absolute path of the previous Titan release
PATH_TO_PREVIOUS_TITAN_RELEASE=$HOME/pdv-testing

# Sets the absolute path of the previous Titan release settings file
PATH_TO_PREVIOUS_SETTINGS_FILE="$PATH_TO_PREVIOUS_TITAN_RELEASE/appsettings.json"

# Gets and sets the absolute path of the current Titan release
relative_path_to_current_titan_release="$(dirname "${BASH_SOURCE[0]}")"
PATH_TO_CURRENT_TITAN_RELEASE="$(realpath "${relative_path_to_current_titan_release}")"

# Sets the name of the service
SERVICE_NAME="pdv-testing.service"

# Sets the name of the temporary file used to store standard errors
STD_ERR_FILE_PATH="./temp-std-err-file.txt"

printf "[1/6] Updating .NET Core..."

if curl -sSL https://dot.net/v1/dotnet-install.sh | bash /dev/stdin -c 5.0 --runtime aspnetcore >/dev/null 2>$STD_ERR_FILE_PATH
then
    printf "SUCCESS"
else
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: encountered an error updating .NET 5.0: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

printf "\n[2/6] Copying previous settings file..."

if [ -f $PATH_TO_PREVIOUS_SETTINGS_FILE >/dev/null 2>&1 ] && cp $PATH_TO_PREVIOUS_SETTINGS_FILE $PATH_TO_CURRENT_TITAN_RELEASE >/dev/null 2>&1
then
    printf "SUCCESS"
else 
    printf "FAILED\n"
    printf "WARNING: couldn't find the previous settings file.\n"
    printf "Settings for GitHub and Jama credentials need to be configured in '~/pdv-testing/appsettings.json' to be able to run tests with titan.\n\n"
    cat << EOF
{
  "GitHub": {
    "Token": "<insert-git-api-token>"
  },
  "Jama": {
    "UserName": "<insert-jama-username>",
    "Password": "<insert-jama-password>"
  },
  "Kestrel": {
    "EndPoints": {
      "Http": {
        "Url": "http://0.0.0.0:80"
      }
    }
  },
  "DockerHost": "unix:///var/run/docker.sock"
}
EOF
    printf "\n"
    printf "Once updated, you'll need to restart the service with 'sudo systemctl restart $SERVICE_NAME'.\n"
    printf "See the wiki for more information: "
    printf "https://github.siriusxm.com/svt/titan/wiki/Setting-up-a-PI-running-PDV-tests#complete-on-pi-1\n"
fi

printf "\n[3/6] Updating symlink..."

if ln -sfn $PATH_TO_CURRENT_TITAN_RELEASE $PATH_TO_PREVIOUS_TITAN_RELEASE >/dev/null 2>$STD_ERR_FILE_PATH
then
    printf "SUCCESS"
else 
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: couldn't update the symlink: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

printf "\n[4/6] Enabling Docker to start at boot..."

if sudo systemctl enable docker.service >/dev/null 2>$STD_ERR_FILE_PATH
then
    printf "SUCCESS"
else 
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: encountered an error enabling Docker: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

printf "\n[5/6] Configuring $SERVICE_NAME..."

# Set the file contents
file_contents="[Unit]
Description=PDV testing application

[Service]
WorkingDirectory=/home/ubuntu/pdv-testing/
# systemd will run this executable to start the service
ExecStart=/home/ubuntu/.dotnet/dotnet /home/ubuntu/pdv-testing/Titan.dll
# to query logs using journalctl, set a logical name here
SyslogIdentifier=pdv-testing

# Use your username to keep things simple.
# If you pick a different user, make sure dotnet and all permissions are set correctly to run the app
# To update permissions, use 'chown yourusername -R /srv/HelloWorld' to take ownership of the folder and files,
#       Use 'chmod +x /srv/HelloWorld/HelloWorld' to allow execution of the executable file
User=root

# This environment variable is necessary when dotnet isn't loaded for the specified user.
# To figure out this value, run 'env | grep DOTNET_ROOT' when dotnet has been loaded into your shell.
Environment=DOTNET_ROOT=/home/ubuntu/.dotnet

[Install]
WantedBy=multi-user.target"

# Write the file contents to the service file
is_created=$( tee << EOF ~/$SERVICE_NAME >/dev/null 2>$STD_ERR_FILE_PATH
$file_contents
EOF
)
status_code=$?

if [ "$status_code" == 0 ]
then
    :
else 
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: the service file could not be created: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

# Copy service file to systemd
if sudo cp ~/$SERVICE_NAME /etc/systemd/system/$SERVICE_NAME >/dev/null 2>$STD_ERR_FILE_PATH
then
    :
else 
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: encountered an error copying service file to systemd: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

# Reload systemd manager configuration
if sudo systemctl daemon-reload >/dev/null 2>$STD_ERR_FILE_PATH
then
    :
else 
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: encountered an error reloading the systemd manager configuration: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

# Enable the service
if sudo systemctl enable $SERVICE_NAME >/dev/null 2>$STD_ERR_FILE_PATH
then
    printf "SUCCESS"
else 
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: encountered an error enabling $SERVICE_NAME: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

printf "\n[6/6] Restarting $SERVICE_NAME..."

# Restart the service
if sudo systemctl restart $SERVICE_NAME >/dev/null 2>$STD_ERR_FILE_PATH
then
    :
else 
    status_code=$?
    error_message=$(cat $STD_ERR_FILE_PATH)

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: encountered an error restarting $SERVICE_NAME: ($error_message).\n" $status_code

    rm -rf $STD_ERR_FILE_PATH

    return $status_code
fi

# Remove temporary file for standard errors
rm -rf $STD_ERR_FILE_PATH

# Allow systemctl time to restart service
sleep 60

# Very the current unit state is active
UNIT_STATE=$(sudo systemctl is-active $SERVICE_NAME)

if [ $UNIT_STATE == "active" ]
then
    printf "SUCCESS"
else
    status_code=$?

    printf "FAILED\n"
    printf "Error %d: couldn't update Titan: couldn't get current unit state: (state: $UNIT_STATE).\n" $status_code

    return $status_code
fi

printf "\n\nScript complete! Navigate to 'http://<pi-ip-address>/' on your PC to view the latest updates.\n"
